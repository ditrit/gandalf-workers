from interface import Interface

class WorkerVisionning(Interface) :
    
    
    def CreateProject(self, version: int):
        pass
 
    def AddMember(self, version: int):
        pass
     
    def RemoveMember(self, version: int):
        pass
    
    def AddHook(self, version: int):
        pass
    
    def DeleteHook(self, version: int):
        pass
    
        
        

