

#from ...libraries.pyclient import ClientGandalf
from pyworker import Worker
import WorkerVisionning
from pygitlab.workers.workerProject import WorkerProject
from pygitlab.workers.workerHook import WorkerAddHook
from pygitlab.workers.workerHook import WorkerDeleteHook
from pygitlab.workers.workerMember import WorkerAddMember
from pygitlab.workers.workerMember import WorkerRemoveMember

from pygitlab.client.clientGitlab import ClientGitlab
from pyclient.ClientGandalf import ClientGandalf

from interface import implements
import sys 
import json


class WorkerGitlab(Worker, implements(WorkerVisionning)):
    
    def __init__(self, version: int, commands: list[str], clientGandalf: ClientGandalf):
        super().__init__(version, commands)
        self.clientGandalf=super().Start()
    
    
    def CreateProject(self, version: int):
        
        clientGitlab= ClientGitlab(url = config.url, token = config.token)
        if not clientGitlab.isValidClient() :
            raise ValueError('Invalid client')
        
         # Thread creation
        workerProject = WorkerProject(self.clientGitlab, self.clientGandalf, self.version)
        workerProject.WorkerProject.Run()

        pass
    
    def AddMember(self, version: int):
        
        clientGitlab= ClientGitlab(url = config.url, token = config.token)
        if not clientGitlab.isValidClient() :
            raise ValueError('Invalid client')
        
         # Thread creation
        workerAddMember = WorkerAddMember(self.clientGitlab, self.clientGandalf, self.version)
        workerAddMember.WorkerAddMember.Run()

        pass
    
    def RemoveMember(self, version: int):
        
        clientGitlab= ClientGitlab(url = config.url, token = config.token)
        if not clientGitlab.isValidClient() :
            raise ValueError('Invalid client')
        
         # Thread creation
        workerRemoveMember = WorkerRemoveMember(self.clientGitlab, self.clientGandalf, self.version)
        workerRemoveMember.WorkerRemoveMember.Run()

        pass
    

    
    def AddHook(self, version: int):
        
        clientGitlab= ClientGitlab(url = config.url, token = config.token)
        if not clientGitlab.isValidClient() :
            raise ValueError('Invalid client')
        
         # Thread creation
        workerAddHook = WorkerAddHook(self.clientGitlab, self.clientGandalf, self.version)
        workerAddHook.WorkerAddHook.Run()

        pass
    
    def DeleteHook(self, version: int):
        
        clientGitlab= ClientGitlab(url = config.url, token = config.token)
        if not clientGitlab.isValidClient() :
            raise ValueError('Invalid client')
        
         # Thread creation
        workerDeleteHook = WorkerDeleteHook(self.clientGitlab, self.clientGandalf, self.version)
        workerDeleteHook.WorkerDeleteHook.Run()

        pass
    
    def Run(self):
        super().Run()
        self.CreateProject(version=self.version)
        self.AddMember(version=self.version)
        self.RemoveMember(version=self.version)
        self.AddHook(version=self.version)
        self.DeleteHook(version=self.version)
    


#MAIN
commands = list()
version = int()

config = json.loads(sys.stdin.read())

workerGitlab = Worker(version, commands) 
workerGitlab.WorkerVisionning.Run()



