
import sys
import logging
from logging.config import fileConfig

fileConfig('logging_config.ini')
logger = logging.getLogger()


def AddHook(clientGitlab, project_id, url, token, push_events=False, tag_push_events=False, merge_requests_events=False, repository_update_events=False, enable_ssl_verification=False):
    try:
        logger.info('function hook.AddHook')
        project=clientGitlab.client.projects.get(project_id)
        hook = project.hooks.create({'url': url, 'token': token, 'push_events': push_events, 'tag_push_events': tag_push_events,
                                                'merge_requests_events': merge_requests_events, 'repository_update_events': repository_update_events,
                                                'enable_ssl_verification': enable_ssl_verification})
        logger.info('The hook' + str(hook.id) + ' has been created')
        return True
    
    except:
        logger.error('Error ',sys.exc_info()[0])
        return None




def DeleteHook(clientGitlab, project_id, hook_id) :
    try:
        logger.info('function hook.DeleteHook')
        project=clientGitlab.client.projects.get(project_id)
        project.hooks.delete(hook_id)
        #TODO ERROR CHECKING 
        return True
    
    except:
        logger.error('Error ',sys.exc_info()[0])
        return None