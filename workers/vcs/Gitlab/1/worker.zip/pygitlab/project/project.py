import sys
import logging
from logging.config import fileConfig

fileConfig('logging_config.ini')
logger = logging.getLogger()


    
def getGitlabAccess(u):
    return 40

def CreateProject(clientGitlab, name, team, template_name = None):
    try:
        logger.info('function project.CreateProject')
        if template_name!= None :
            project = clientGitlab.client.projects.create({'name': name, 'template_name': template_name})
        else: 
            project = clientGitlab.client.projects.create({'name': name})
        #TODO : création aussi du "team account"??
        members = []
        for u in team: #on définit ici la team comme une liste des emails des membres
            #TODO vérifier que les u ont bien un compte gitlab et leur en créer un sinon (externe à cette fonction)
            userGitlab=clientGitlab.client.users.list(email = u)[0]
            members.append( project.members.create({'user_id': userGitlab.id, 'access_level': getGitlabAccess(u) })) 
        logger.info('the project'+ str(project.id)+ 'has been created')
        return [project.id , True]
    
    except:
        logger.error('Error ',sys.exc_info()[0])
        return None



def AddMember(clientGitlab, project_id, user_email):
    try:
        logger.info('function project.AddMember')
        project = clientGitlab.client.projects.get(project_id)
        #TODO vérifier que les u ont bien un compte gitlab et leur en créer un sinon (externe à cette fonction)
        userGitlab=clientGitlab.client.users.list(email=user_email)[0]
        member = project.members.create({'user_id': userGitlab.id, 'access_level': getGitlabAccess(userGitlab) })
        logger.info('the user ' + member.name + 'has joined the project' + str(project.id))
        
        return True
    
    except:
        logger.error('Error ',sys.exc_info()[0])
        return None



def RemoveMember(clientGitlab, project_id, user_email):
    try:
        logger.info(' fuction project.RemoveMember')
        project = clientGitlab.client.projects.get(project_id)
        userGitlab=clientGitlab.client.users.list(email=user_email)[0]
        project.members.delete(userGitlab.id)
        logger.info('the member ' + userGitlab.name + 'has been removed from the project' + str(project.id))
        
        return True
    
    except:
        logger.error('Error ',sys.exc_info()[0])
        return None


