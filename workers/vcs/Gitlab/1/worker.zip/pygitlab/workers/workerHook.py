
import json
from threading import Thread

from pygitlab.hook import hookPayload
from pygitlab.hook import hook
from pygitlab.client.clientGitlab import ClientGitlab
from pyclient import ClientGandalf
from pyclient.models import Options

import sys
import logging
from logging.config import fileConfig

fileConfig('logging_config.ini')
logger = logging.getLogger()



class WorkerAddHook(Thread):

    def __init__(self, clientGitlab, clientGandalf, version):

        Thread.__init__(self)
        self.clientGandalf = clientGandalf
        self.clientGitlab = clientGitlab
        self.version = version
        
    

    def Run(self):
        AddHookThread = Thread(target=self.AddHook, args=(self,))
        AddHookThread.start()


    def AddHook(self):
        try:
            logger.info('function workerHook.AddHook')
            id = self.clientGandalf.CreateIteratorCommand()
    
            while True:
                command = self.clientGandalf.WaitCommand("ADD_HOOK", id, self.version)
    
                jsonHookPayload = json.load(command.GetPayload())
                addHookPayload = hookPayload.AddHookPayload(jsonHookPayload)
    
                if addHookPayload != "":
                    
    
                    result = hook.AddHook(clientGitlab=self.clientGitlab, project_id=addHookPayload.ProjectID, url=addHookPayload.Url, token=addHookPayload.Token, push_events=addHookPayload.PushEvents, tag_push_events=addHookPayload.TagPushEvents, merge_requests_events=addHookPayload.MergeRequestsEvents, repository_update_events=addHookPayload.RepositoryUpdateEvents, enable_ssl_verification=addHookPayload.EnableSslVerification)
    
                    if result :
                        print("SUCCES")
                        self.clientGandalf.SendReply(command.GetCommand(), "SUCCES", command.GetUUID(), Options("",""))
                    else:
                        print("FAIL")
                        self.clientGandalf.SendReply(command.GetCommand(), "FAIL", command.GetUUID(), Options("",""))
                    
        except:
            logger.error('Error ',sys.exc_info()[0])
            return None
 

class WorkerDeleteHook(Thread):

    def __init__(self, clientGitlab, clientGandalf, version):

        Thread.__init__(self)
        self.clientGandalf = clientGandalf
        self.clientGitlab = clientGitlab
        self.version = version
        
    

    def Run(self):
        DeleteHookThread = Thread(target=self.DeleteHook, args=(self,))
        DeleteHookThread.start()

    def DeleteHook(self):
        try:
            logger.info('function workerHook.DeleteHook')
            id = self.clientGandalf.CreateIteratorCommand()
    
            while True:
                command = self.clientGandalf.WaitCommand("DELETE_HOOK", id, self.version)
    
                jsonHookPayload = json.load(command.GetPayload())
                deleteHookPayload = hookPayload.DeleteHookPayload(jsonHookPayload)
    
                if deleteHookPayload != "":
    
                    result = hook.DeleteHook(clientGitlab=self.clientGitlab, project_id=deleteHookPayload.ProjectID, hook_id=deleteHookPayload.HookID)
    
                    if result :
                        print("SUCCES")
                        self.clientGandalf.SendReply(command.GetCommand(), "SUCCES", command.GetUUID(), Options("",""))
                    else:
                        print("FAIL")
                        self.clientGandalf.SendReply(command.GetCommand(), "FAIL", command.GetUUID(), Options("",""))
                        
        except:
            logger.error('Error ',sys.exc_info()[0])
            return None
    
