
# import de fonction lié au repo
import json
from threading import Thread
from pygitlab.project import projectPayload
from pygitlab.project import project
from pygitlab.project.issue import issuePayload
from pygitlab.project.issue import issue
from pygitlab.client.clientGitlab import ClientGitlab
from pyclient import ClientGandalf
from pyclient.models import Options

import sys
import logging
from logging.config import fileConfig

fileConfig('logging_config.ini')
logger = logging.getLogger()


class WorkerProject(Thread):

    def __init__(self, clientGitlab, clientGandalf, version):

        Thread.__init__(self)
        self.clientGandalf = clientGandalf
        self.clientGitlab = clientGitlab
        self.version = version
        

    def Run(self):
        CreateProjectThread = Thread(target=self.CreateProject, args=(self,))
        CreateProjectThread.start()
    

    def CreateProject(self):
        try:
            logger.info('function workerProject.CreateProject')
            id = self.clientGandalf.CreateIteratorCommand()
    
            while True:
                command = self.clientGandalf.WaitCommand("CREATE_PROJECT", id, self.version)
    
                
                jsonProjectPayload = json.load(command.GetPayload())
                createProjectPayload = projectPayload.CreateProjectPayload(jsonProjectPayload)
    
                if createProjectPayload != "":
                    
                    result = project.CreateProject(clientGitlab=self.clientGitlab, name=createProjectPayload.Name, team=createProjectPayload.Team, template_name=createProjectPayload.TemplateName)
    
                    if result :
                        print("SUCCES")
                        self.clientGandalf.SendReply(command.GetCommand(), "SUCCES", command.GetUUID(), Options("",""))
                    else:
                        print("FAIL")
                        self.clientGandalf.SendReply(command.GetCommand(), "FAIL", command.GetUUID(), Options("",""))
                    
        except:
            logger.error('Error ',sys.exc_info()[0])
            return None
                        
        

