

import logging
import json
import sys
from flask import Flask, request, abort

from pyclient.ClientGandalf import ClientGandalf
from pyclient.models import Options
#import serverUrlv

config = json.loads(sys.stdin.read())
#url = serverUrl.Urls.returnHashURLS()

application = Flask(__name__)

@application.route( "/", methods=['POST'])
def index():
    
    if request.method != 'POST':
        abort(501)
        
    if request.method == 'POST':
        
        # Gather data
        try:
            payload = request.get_json()
        except Exception:
            logging.warning('Request parsing failed')
            abort(400)
       
        clientGandalf=ClientGandalf( identity=config.Identity, clientConnections=config.ClientEventConnection)
        clientGandalf.SendEvent("Gitlab", "HOOK", Options("", payload))
        


if __name__ == '__main__':
    application.run(debug=False)