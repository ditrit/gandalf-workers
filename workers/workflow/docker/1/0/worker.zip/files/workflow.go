package main

import (
	"fmt"

	"github.com/ditrit/gandalf/libraries/goclient"
)

func Workflow(clientGandalf *goclient.ClientGandalf) {
	fmt.Println("Test Workflow")

}
